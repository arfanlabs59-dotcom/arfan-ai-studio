-- ARFAN AI HUB — PROFILE PICTURE SYSTEM
-- Add to the existing Supabase schema/migration.

alter table public.users
  add column if not exists profile_photo_file_id text,
  add column if not exists profile_photo_url text,
  add column if not exists profile_photo_updated_at timestamptz,
  add column if not exists profile_visibility text not null default 'members';

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'users_profile_visibility_check'
  ) then
    alter table public.users
      add constraint users_profile_visibility_check
      check (profile_visibility in ('everyone','members','only_me'));
  end if;
end $$;

create index if not exists idx_users_profile_photo_updated_at
  on public.users(profile_photo_updated_at);
