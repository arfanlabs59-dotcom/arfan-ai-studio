/*
Provider boundary.

The bot never exposes provider keys to Telegram users.
Each adapter must return:
{ providerJobId, resultUrl, raw }

Current official API details change independently, so provider-specific
request bodies/models are intentionally configured here rather than trusted
from client input.

Leonardo's official docs currently document generation endpoints under
cloud.leonardo.ai/api/rest and bearer authentication.
Runway maintains its own current SDK/API documentation.
Other providers must be configured from their current official documentation.
*/

export async function runProvider(toolCode, input, env = process.env) {
  if (toolCode === "chatgpt") return openAI(input, env);
  if (toolCode === "leonardo") return leonardo(input, env);
  throw new Error(`Provider adapter not configured: ${toolCode}`);
}

async function openAI(input, env) {
  if (!env.OPENAI_API_KEY || !env.OPENAI_MODEL) {
    throw new Error("OpenAI provider is not configured");
  }

  const r = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${env.OPENAI_API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: env.OPENAI_MODEL,
      input: String(input).slice(0, 10000)
    })
  });

  const raw = await r.json();
  if (!r.ok) throw new Error(raw?.error?.message || "OpenAI request failed");

  return {
    providerJobId: null,
    resultUrl: null,
    raw
  };
}

async function leonardo(input, env) {
  if (!env.LEONARDO_API_KEY || !env.LEONARDO_MODEL_ID) {
    throw new Error("Leonardo provider is not configured");
  }

  const r = await fetch("https://cloud.leonardo.ai/api/rest/v1/generations", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${env.LEONARDO_API_KEY}`,
      "Content-Type": "application/json",
      "Accept": "application/json"
    },
    body: JSON.stringify({
      prompt: String(input).slice(0, 9999),
      modelId: env.LEONARDO_MODEL_ID,
      num_images: 1,
      width: 1024,
      height: 1024,
      public: false
    })
  });

  const raw = await r.json();
  if (!r.ok) throw new Error(raw?.error?.message || "Leonardo request failed");

  return {
    providerJobId: raw?.sdGenerationJob?.generationId || raw?.generationId || null,
    resultUrl: null,
    raw
  };
}
