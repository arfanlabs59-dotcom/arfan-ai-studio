export const AI_TOOLS = Object.freeze({
  chatgpt: { name: "ChatGPT — Writing", credits: 2, input: "text" },
  leonardo: { name: "Leonardo AI — Image Generate", credits: 5, input: "text" },
  gamma: { name: "Gamma — PPT Generate", credits: 5, input: "text" },
  runway: { name: "Runway — Video Generate", credits: 15, input: "text" },
  elevenlabs: { name: "ElevenLabs — Voice Generate", credits: 8, input: "text" },
  removebg: { name: "Remove.bg — Background Remove", credits: 3, input: "photo" },
  upscale: { name: "Upscale.media — Enhance", credits: 3, input: "photo" },
  ideogram: { name: "Ideogram — Text to Image", credits: 5, input: "text" },
  otter: { name: "Otter.ai — Meeting to Text", credits: 4, input: "audio" },
  chatpdf: { name: "ChatPDF — PDF to MCQ", credits: 4, input: "document" }
});
