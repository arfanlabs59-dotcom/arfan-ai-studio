import { startRequest, completeRequest, failRequest } from "../services/credits.js";
import { runProvider } from "./providers.js";

export async function executeAi({ telegramId, toolCode, requestId, input }) {
  const reservation = await startRequest(telegramId, toolCode, requestId);
  const requestUuid = reservation?.request_uuid || reservation?.id;
  if (!requestUuid) throw new Error("Credit reservation failed");

  try {
    const result = await runProvider(toolCode, input);
    await completeRequest(requestUuid, result.providerJobId, result.resultUrl, result.raw);
    return result;
  } catch (err) {
    await failRequest(requestUuid, err.message);
    throw err;
  }
}
