export const config = {
  telegramToken: process.env.TELEGRAM_BOT_TOKEN || "",
  webhookSecret: process.env.TELEGRAM_WEBHOOK_SECRET || "",
  adminId: Number(process.env.ADMIN_TELEGRAM_ID || "6386740978"),
  paymentNumber: process.env.PAYMENT_NUMBER || "01316963411",
  support: process.env.SUPPORT_USERNAME || "Arfanvai11",
  aiRevenueRate: Number(process.env.AI_REVENUE_RATE || "100"),
  supabaseUrl: process.env.SUPABASE_URL || "",
  serviceRoleKey: process.env.SUPABASE_SERVICE_ROLE_KEY || ""
};
