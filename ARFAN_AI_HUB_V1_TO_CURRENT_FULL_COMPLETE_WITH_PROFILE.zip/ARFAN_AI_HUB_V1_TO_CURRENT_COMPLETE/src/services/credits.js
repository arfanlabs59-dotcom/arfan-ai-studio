import { rpc } from "../db.js";

export const getCreditBalance = (telegramId) =>
  rpc("get_credit_balance", { p_telegram_id: telegramId });

export const claimDailyBonus = (telegramId) =>
  rpc("claim_ai_daily_bonus", { p_telegram_id: telegramId });

export const startRequest = (telegramId, toolCode, requestId) =>
  rpc("start_ai_request", {
    p_telegram_id: telegramId,
    p_tool_code: toolCode,
    p_request_id: requestId
  });

export const completeRequest = (requestUuid, providerJobId, resultUrl, providerResponse = {}) =>
  rpc("complete_ai_request", {
    p_request_uuid: requestUuid,
    p_provider_job_id: providerJobId || null,
    p_result_url: resultUrl || null,
    p_provider_response: providerResponse
  });

export const failRequest = (requestUuid, error) =>
  rpc("fail_ai_request", {
    p_request_uuid: requestUuid,
    p_error: error
  });
