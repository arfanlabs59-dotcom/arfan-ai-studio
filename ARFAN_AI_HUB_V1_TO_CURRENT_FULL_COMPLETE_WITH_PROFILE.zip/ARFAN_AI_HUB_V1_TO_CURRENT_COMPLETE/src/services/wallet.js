import { rpc } from "../db.js";

export const getWalletBalance = (telegramId) =>
  rpc("get_wallet_balance", { p_telegram_id: telegramId });

export const createWithdrawal = (telegramId, amount, method, account) =>
  rpc("create_withdrawal", {
    p_telegram_id: telegramId,
    p_amount: amount,
    p_method: method,
    p_account: account
  });

export const approveWithdrawal = (adminId, id) =>
  rpc("approve_withdrawal", { p_admin_id: adminId, p_withdrawal_id: id });

export const rejectWithdrawal = (adminId, id, reason) =>
  rpc("reject_withdrawal", {
    p_admin_id: adminId,
    p_withdrawal_id: id,
    p_reason: reason || null
  });

export const markWithdrawalPaid = (adminId, id, reference) =>
  rpc("mark_withdrawal_paid", {
    p_admin_id: adminId,
    p_withdrawal_id: id,
    p_payout_reference: reference || null
  });
