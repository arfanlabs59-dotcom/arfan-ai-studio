import { rpc } from "../db.js";

export function normalizeTrxId(value) {
  return String(value || "").trim().toUpperCase().replace(/\s+/g, "");
}

export async function createPremiumOrder({
  telegramId, packageCode, method, paymentType, trxId, screenshotFileId
}) {
  const trx = normalizeTrxId(trxId);
  if (!trx || !screenshotFileId) throw new Error("TRX ID and screenshot are required");

  return rpc("create_premium_order", {
    p_telegram_id: telegramId,
    p_package_code: packageCode,
    p_payment_method: method,
    p_payment_type: paymentType || null,
    p_trx_id: trx,
    p_screenshot_file_id: screenshotFileId
  });
}

export async function matchSupportEvidence(adminId, orderId, supportTrxId, supportScreenshotFileId) {
  return rpc("match_payment_evidence", {
    p_admin_id: adminId,
    p_order_id: orderId,
    p_support_trx_id: normalizeTrxId(supportTrxId),
    p_support_screenshot_file_id: supportScreenshotFileId
  });
}

export async function verifyPremium(adminId, orderId) {
  return rpc("verify_premium_order", {
    p_admin_id: adminId,
    p_order_id: orderId
  });
}

export async function rejectPremium(adminId, orderId, reason) {
  return rpc("reject_premium_order", {
    p_admin_id: adminId,
    p_order_id: orderId,
    p_reason: reason || null
  });
}
