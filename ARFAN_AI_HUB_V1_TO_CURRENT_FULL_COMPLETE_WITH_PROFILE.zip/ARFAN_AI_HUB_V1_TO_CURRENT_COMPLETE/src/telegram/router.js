import { config } from "../config.js";

export async function handleUpdate(bot, update) {
  const msg = update?.message;
  if (!msg?.chat?.id) return;

  const id = msg.chat.id;
  const text = msg.text?.trim() || "";

  if (text === "/start") {
    await bot.telegram.sendMessage(id,
      "🤖 ARFAN AI HUB\n\n10 AI Tools • AI Credits • Premium • Wallet\n\nUse /menu to open the menu.");
    return;
  }

  if (text === "/menu") {
    await bot.telegram.sendMessage(id,
      "Main Menu\n\n🤖 AI Tools\n💳 Buy Plan\n🪙 AI Credits\n💰 Wallet\n💸 Withdraw\n⭐ Premium\n🎁 Daily Bonus\n🛒 Marketplace\n🆘 Support");
    return;
  }

  if (text === "/payment") {
    await bot.telegram.sendMessage(id,
      `Payment number: ${config.paymentNumber}\n\nTRX ID + screenshot are mandatory.\nAdmin verification is required before activation.`);
    return;
  }

  if (text === "/support") {
    await bot.telegram.sendMessage(id, `Support: @${config.support}`);
    return;
  }

  await bot.telegram.sendMessage(id, "Use /menu to continue.");
}
