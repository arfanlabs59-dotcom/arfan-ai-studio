import { Telegraf } from "telegraf";
import { config } from "../src/config.js";
import { handleUpdate } from "../src/telegram/router.js";

const bot = new Telegraf(config.telegramToken);

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ ok: false });
  if (
    config.webhookSecret &&
    req.headers["x-telegram-bot-api-secret-token"] !== config.webhookSecret
  ) {
    return res.status(401).json({ ok: false });
  }

  try {
    await handleUpdate(bot, req.body);
    return res.status(200).json({ ok: true });
  } catch (err) {
    console.error("telegram_handler_error", err);
    return res.status(500).json({ ok: false });
  }
}
