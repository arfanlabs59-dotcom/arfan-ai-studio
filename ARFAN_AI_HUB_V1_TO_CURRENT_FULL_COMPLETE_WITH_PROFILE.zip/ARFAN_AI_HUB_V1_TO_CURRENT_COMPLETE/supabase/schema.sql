create extension if not exists pgcrypto;

-- =========================
-- CORE USERS / ADMIN
-- =========================
create table if not exists public.users (
  telegram_id bigint primary key,
  username text,
  balance bigint not null default 0 check (balance >= 0),
  status text not null default 'active' check (status in ('active','banned')),
  is_active_account boolean not null default false,
  is_premium boolean not null default false,
  premium_expires_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.admins (
  telegram_id bigint primary key references public.users(telegram_id) on delete cascade,
  created_at timestamptz not null default now()
);

insert into public.users(telegram_id, username)
values (6386740978, 'admin')
on conflict (telegram_id) do nothing;

insert into public.admins(telegram_id)
values (6386740978)
on conflict do nothing;

-- =========================
-- WALLET
-- =========================
create table if not exists public.wallet_transactions (
  id uuid primary key default gen_random_uuid(),
  telegram_id bigint not null references public.users(telegram_id),
  tx_type text not null,
  amount bigint not null,
  reference_id text,
  created_at timestamptz not null default now()
);

create unique index if not exists wallet_tx_ref_uq
on public.wallet_transactions(telegram_id, tx_type, reference_id)
where reference_id is not null;

-- =========================
-- AI CREDITS
-- =========================
create table if not exists public.ai_credit_wallets (
  telegram_id bigint primary key references public.users(telegram_id) on delete cascade,
  balance bigint not null default 0 check (balance >= 0),
  total_purchased bigint not null default 0,
  total_used bigint not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.ai_credit_transactions (
  id uuid primary key default gen_random_uuid(),
  telegram_id bigint not null references public.users(telegram_id),
  tx_type text not null check (tx_type in ('purchase','ai_use','refund','promo','admin_grant','bonus')),
  amount bigint not null,
  reference_id text not null,
  created_at timestamptz not null default now(),
  unique(telegram_id, tx_type, reference_id)
);

create table if not exists public.ai_tools (
  code text primary key,
  name text not null,
  cost_per_use bigint not null check (cost_per_use > 0),
  status text not null default 'active' check (status in ('active','inactive')),
  created_at timestamptz not null default now()
);

insert into public.ai_tools(code,name,cost_per_use) values
('chatgpt','ChatGPT — Writing',2),
('leonardo','Leonardo AI — Image Generate',5),
('gamma','Gamma — PPT Generate',5),
('runway','Runway — Video Generate',15),
('elevenlabs','ElevenLabs — Voice Generate',8),
('removebg','Remove.bg — Background Remove',3),
('upscale','Upscale.media — Enhance',3),
('ideogram','Ideogram — Text to Image',5),
('otter','Otter.ai — Meeting to Text',4),
('chatpdf','ChatPDF — PDF to MCQ',4)
on conflict(code) do update
set name=excluded.name, cost_per_use=excluded.cost_per_use;

create table if not exists public.ai_requests (
  id uuid primary key default gen_random_uuid(),
  telegram_id bigint not null references public.users(telegram_id),
  tool_code text not null references public.ai_tools(code),
  request_id text not null,
  credits bigint not null check (credits > 0),
  status text not null check (status in ('reserved','processing','succeeded','failed','refunded')),
  provider_job_id text,
  result_url text,
  provider_response jsonb not null default '{}'::jsonb,
  error_message text,
  delivery_status text not null default 'pending',
  delivery_attempts int not null default 0,
  delivery_error text,
  result_delivered_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(telegram_id, request_id)
);

-- =========================
-- PREMIUM / PAYMENT
-- =========================
create table if not exists public.premium_packages (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  name text not null,
  duration_days int not null,
  price_bdt bigint not null,
  included_credits bigint not null,
  is_vip boolean not null default false,
  status text not null default 'active',
  created_at timestamptz not null default now()
);

insert into public.premium_packages(code,name,duration_days,price_bdt,included_credits,is_vip) values
('easy','Easy',7,99,150,false),
('normal','Normal',15,299,500,false),
('pro','Pro',20,599,1000,false),
('pro_plus','Pro Plus',25,799,1500,true),
('pro_plus_max','Pro Plus Max',30,1299,2500,true)
on conflict(code) do update set
name=excluded.name,
duration_days=excluded.duration_days,
price_bdt=excluded.price_bdt,
included_credits=excluded.included_credits,
is_vip=excluded.is_vip;

create table if not exists public.premium_orders (
  id uuid primary key default gen_random_uuid(),
  telegram_id bigint not null references public.users(telegram_id),
  package_id uuid not null references public.premium_packages(id),
  amount_bdt bigint not null,
  payment_method text not null check(payment_method in ('bkash','nagad')),
  payment_type text,
  trx_id text not null,
  trxid_norm text not null unique,
  screenshot_file_id text not null,
  screenshot_storage_key text,
  support_trx_id text,
  support_screenshot_file_id text,
  match_status text not null default 'unmatched'
    check(match_status in ('unmatched','matched','mismatch')),
  status text not null default 'pending'
    check(status in ('pending','verified','rejected')),
  rejection_reason text,
  verified_by bigint references public.users(telegram_id),
  verified_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- =========================
-- DAILY / TASK / QUIZ / REFERRAL
-- =========================
create table if not exists public.credit_events (
  id uuid primary key default gen_random_uuid(),
  telegram_id bigint not null references public.users(telegram_id),
  event_type text not null,
  reference_id text not null,
  amount bigint not null,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now(),
  unique(telegram_id,event_type,reference_id)
);

create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  reward bigint not null,
  status text not null default 'active',
  created_at timestamptz not null default now()
);

create table if not exists public.task_submissions (
  id uuid primary key default gen_random_uuid(),
  task_id uuid not null references public.tasks(id),
  telegram_id bigint not null references public.users(telegram_id),
  proof_text text,
  proof_file_id text,
  status text not null default 'pending',
  created_at timestamptz not null default now()
);

create table if not exists public.quizzes (
  id uuid primary key default gen_random_uuid(),
  question text not null,
  answer text not null,
  reward bigint not null default 3,
  status text not null default 'active'
);

create table if not exists public.quiz_attempts (
  id uuid primary key default gen_random_uuid(),
  quiz_id uuid not null references public.quizzes(id),
  telegram_id bigint not null references public.users(telegram_id),
  is_correct boolean not null,
  created_at timestamptz not null default now()
);

create table if not exists public.referrals (
  id uuid primary key default gen_random_uuid(),
  referrer_id bigint not null references public.users(telegram_id),
  referred_id bigint not null references public.users(telegram_id),
  reward_given boolean not null default false,
  created_at timestamptz not null default now(),
  unique(referred_id),
  check(referrer_id <> referred_id)
);

-- =========================
-- WITHDRAWAL
-- =========================
create table if not exists public.withdrawals (
  id uuid primary key default gen_random_uuid(),
  telegram_id bigint not null references public.users(telegram_id),
  amount bigint not null check(amount >= 500),
  method text not null check(method in ('bkash','nagad')),
  account text not null,
  status text not null default 'pending'
    check(status in ('pending','approved','rejected','paid')),
  payout_reference text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- =========================
-- MARKETPLACE
-- =========================
create table if not exists public.marketplace_listings (
  id uuid primary key default gen_random_uuid(),
  seller_id bigint not null references public.users(telegram_id),
  title text not null,
  price bigint not null check(price > 0),
  status text not null default 'active',
  created_at timestamptz not null default now()
);

create table if not exists public.marketplace_orders (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.marketplace_listings(id),
  buyer_id bigint not null references public.users(telegram_id),
  seller_id bigint not null references public.users(telegram_id),
  price bigint not null,
  platform_fee bigint not null,
  seller_amount bigint not null,
  status text not null default 'pending',
  idempotency_key text unique not null,
  created_at timestamptz not null default now()
);

-- =========================
-- REVENUE / AUDIT
-- =========================
create table if not exists public.admin_credit_revenue (
  id uuid primary key default gen_random_uuid(),
  telegram_id bigint not null references public.users(telegram_id),
  ai_request_id uuid not null references public.ai_requests(id),
  credits_used bigint not null,
  rate_bdt_per_credit bigint not null check(rate_bdt_per_credit in (50,80,100)),
  revenue_bdt bigint not null,
  reference_id text unique not null,
  created_at timestamptz not null default now()
);

create table if not exists public.admin_revenue_ledger (
  id uuid primary key default gen_random_uuid(),
  source text not null check(source in ('ai_credit_usage','marketplace_fee','premium_sale','system_bonus','other')),
  reference_id text not null,
  amount_bdt bigint not null,
  settled_amount_bdt bigint not null default 0,
  withdrawable_amount_bdt bigint not null default 0,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now(),
  unique(source,reference_id)
);

create table if not exists public.admin_logs (
  id uuid primary key default gen_random_uuid(),
  admin_id bigint not null references public.users(telegram_id),
  action text not null,
  target_id text,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);

-- =========================
-- CREDIT RULES / LOTS
-- =========================
create table if not exists public.credit_rules (
  code text primary key,
  name text not null,
  credit_amount bigint not null,
  daily_limit bigint,
  status text not null default 'active',
  expires_after_days int,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.credit_lots (
  id uuid primary key default gen_random_uuid(),
  telegram_id bigint not null references public.users(telegram_id),
  source text not null,
  amount bigint not null,
  remaining bigint not null,
  expires_at timestamptz,
  created_at timestamptz not null default now()
);

-- =========================
-- RPCS
-- =========================

create or replace function public.is_admin(p_id bigint)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists(select 1 from public.admins where telegram_id = p_id);
$$;

create or replace function public.get_credit_balance(p_telegram_id bigint)
returns bigint
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(balance,0) from public.ai_credit_wallets
  where telegram_id = p_telegram_id;
$$;

create or replace function public.get_wallet_balance(p_telegram_id bigint)
returns bigint
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(balance,0) from public.users where telegram_id=p_telegram_id;
$$;

create or replace function public._grant_credit_internal(
  p_telegram_id bigint,
  p_amount bigint,
  p_tx_type text,
  p_reference_id text,
  p_source text default 'system',
  p_expiry timestamptz default null,
  p_metadata jsonb default '{}'::jsonb
)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_inserted int;
  v_balance bigint;
begin
  if p_amount <= 0 then raise exception 'invalid credit amount'; end if;

  insert into public.ai_credit_wallets(telegram_id)
  values(p_telegram_id)
  on conflict(telegram_id) do nothing;

  insert into public.ai_credit_transactions(telegram_id,tx_type,amount,reference_id)
  values(p_telegram_id,p_tx_type,p_amount,p_reference_id)
  on conflict(telegram_id,tx_type,reference_id) do nothing;

  get diagnostics v_inserted = row_count;

  if v_inserted = 1 then
    update public.ai_credit_wallets
    set balance=balance+p_amount,
        total_purchased=total_purchased+
          case when p_tx_type='purchase' then p_amount else 0 end,
        updated_at=now()
    where telegram_id=p_telegram_id;

    insert into public.credit_lots(telegram_id,source,amount,remaining,expires_at)
    values(p_telegram_id,p_source,p_amount,p_amount,p_expiry);
  end if;

  select balance into v_balance
  from public.ai_credit_wallets
  where telegram_id=p_telegram_id;

  return jsonb_build_object(
    'ok',true,
    'inserted',v_inserted=1,
    'balance',v_balance
  );
end;
$$;

create or replace function public.start_ai_request(
  p_telegram_id bigint,
  p_tool_code text,
  p_request_id text
)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_user public.users%rowtype;
  v_tool public.ai_tools%rowtype;
  v_wallet public.ai_credit_wallets%rowtype;
  v_id uuid;
begin
  select * into v_user from public.users where telegram_id=p_telegram_id for update;
  if not found or v_user.status<>'active' or not v_user.is_active_account
    then raise exception 'account not active'; end if;

  select * into v_tool from public.ai_tools where code=p_tool_code and status='active';
  if not found then raise exception 'tool unavailable'; end if;

  if exists(select 1 from public.ai_requests where telegram_id=p_telegram_id and request_id=p_request_id)
    then raise exception 'duplicate request'; end if;

  insert into public.ai_credit_wallets(telegram_id)
  values(p_telegram_id) on conflict do nothing;

  select * into v_wallet from public.ai_credit_wallets
  where telegram_id=p_telegram_id for update;

  if v_wallet.balance < v_tool.cost_per_use then raise exception 'insufficient AI credits'; end if;

  update public.ai_credit_wallets
  set balance=balance-v_tool.cost_per_use,
      total_used=total_used+v_tool.cost_per_use,
      updated_at=now()
  where telegram_id=p_telegram_id;

  v_id := gen_random_uuid();

  insert into public.ai_requests(
    id,telegram_id,tool_code,request_id,credits,status
  ) values(
    v_id,p_telegram_id,p_tool_code,p_request_id,v_tool.cost_per_use,'reserved'
  );

  insert into public.ai_credit_transactions(
    telegram_id,tx_type,amount,reference_id
  ) values(
    p_telegram_id,'ai_use',-v_tool.cost_per_use,v_id::text
  );

  return jsonb_build_object(
    'ok',true,
    'request_uuid',v_id,
    'credits',v_tool.cost_per_use
  );
end;
$$;

create or replace function public.complete_ai_request(
  p_request_uuid uuid,
  p_provider_job_id text default null,
  p_result_url text default null,
  p_provider_response jsonb default '{}'::jsonb
)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare v_status text;
begin
  select status into v_status from public.ai_requests
  where id=p_request_uuid for update;

  if v_status is null then raise exception 'request not found'; end if;
  if v_status not in ('reserved','processing') then
    raise exception 'invalid request state';
  end if;

  update public.ai_requests
  set status='succeeded',
      provider_job_id=p_provider_job_id,
      result_url=p_result_url,
      provider_response=p_provider_response,
      updated_at=now()
  where id=p_request_uuid;

  return jsonb_build_object('ok',true,'status','succeeded');
end;
$$;

create or replace function public.fail_ai_request(
  p_request_uuid uuid,
  p_error text
)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_req public.ai_requests%rowtype;
begin
  select * into v_req from public.ai_requests
  where id=p_request_uuid for update;

  if not found then raise exception 'request not found'; end if;
  if v_req.status in ('failed','refunded','succeeded') then
    return jsonb_build_object('ok',true,'status',v_req.status);
  end if;

  update public.ai_credit_wallets
  set balance=balance+v_req.credits,
      total_used=greatest(0,total_used-v_req.credits),
      updated_at=now()
  where telegram_id=v_req.telegram_id;

  insert into public.ai_credit_transactions(
    telegram_id,tx_type,amount,reference_id
  ) values(v_req.telegram_id,'refund',v_req.credits,p_request_uuid::text)
  on conflict do nothing;

  update public.ai_requests
  set status='refunded', error_message=p_error, updated_at=now()
  where id=p_request_uuid;

  return jsonb_build_object('ok',true,'status','refunded');
end;
$$;

create or replace function public.create_premium_order(
  p_telegram_id bigint,
  p_package_code text,
  p_payment_method text,
  p_payment_type text,
  p_trx_id text,
  p_screenshot_file_id text
)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_pkg public.premium_packages%rowtype;
  v_id uuid;
  v_trx text;
begin
  v_trx := upper(regexp_replace(trim(p_trx_id),'\s+','','g'));
  if v_trx='' or p_screenshot_file_id is null or trim(p_screenshot_file_id)=''
    then raise exception 'TRX and screenshot are required'; end if;

  select * into v_pkg from public.premium_packages
  where code=p_package_code and status='active';

  if not found then raise exception 'invalid package'; end if;
  if p_payment_method not in ('bkash','nagad') then raise exception 'invalid payment method'; end if;

  insert into public.premium_orders(
    telegram_id,package_id,amount_bdt,payment_method,payment_type,
    trx_id,trxid_norm,screenshot_file_id
  ) values(
    p_telegram_id,v_pkg.id,v_pkg.price_bdt,p_payment_method,p_payment_type,
    p_trx_id,v_trx,p_screenshot_file_id
  )
  returning id into v_id;

  return jsonb_build_object('ok',true,'order_id',v_id,'status','pending');
exception
  when unique_violation then
    raise exception 'TRX ID already submitted';
end;
$$;

create or replace function public.match_payment_evidence(
  p_admin_id bigint,
  p_order_id uuid,
  p_support_trx_id text,
  p_support_screenshot_file_id text
)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.premium_orders%rowtype;
  v_norm text;
  v_match boolean;
begin
  if not public.is_admin(p_admin_id) then raise exception 'admin only'; end if;

  select * into v_order from public.premium_orders
  where id=p_order_id for update;

  if not found then raise exception 'order not found'; end if;

  v_norm := upper(regexp_replace(trim(p_support_trx_id),'\s+','','g'));
  v_match := v_norm=v_order.trxid_norm;

  update public.premium_orders
  set support_trx_id=p_support_trx_id,
      support_screenshot_file_id=p_support_screenshot_file_id,
      match_status=case when v_match then 'matched' else 'mismatch' end,
      updated_at=now()
  where id=p_order_id;

  insert into public.admin_logs(admin_id,action,target_id,metadata)
  values(p_admin_id,'payment_evidence_match',p_order_id::text,
    jsonb_build_object('matched',v_match));

  return jsonb_build_object('ok',true,'matched',v_match);
end;
$$;

create or replace function public.verify_premium_order(
  p_admin_id bigint,
  p_order_id uuid
)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.premium_orders%rowtype;
  v_pkg public.premium_packages%rowtype;
  v_user public.users%rowtype;
  v_ref text;
begin
  if not public.is_admin(p_admin_id) then raise exception 'admin only'; end if;

  select * into v_order from public.premium_orders where id=p_order_id for update;
  if not found then raise exception 'order not found'; end if;
  if v_order.status<>'pending' then
    return jsonb_build_object('ok',true,'status',v_order.status);
  end if;

  select * into v_pkg from public.premium_packages where id=v_order.package_id;
  select * into v_user from public.users where telegram_id=v_order.telegram_id for update;

  if v_order.match_status<>'matched' then
    raise exception 'payment evidence not matched';
  end if;

  update public.premium_orders
  set status='verified', verified_by=p_admin_id, verified_at=now(), updated_at=now()
  where id=p_order_id;

  update public.users
  set is_active_account=true,
      is_premium=true,
      premium_expires_at=greatest(coalesce(premium_expires_at,now()),
        now()) + make_interval(days=>v_pkg.duration_days),
      updated_at=now()
  where telegram_id=v_order.telegram_id;

  v_ref := 'premium:' || p_order_id::text;

  perform public._grant_credit_internal(
    v_order.telegram_id,
    v_pkg.included_credits,
    'purchase',
    v_ref,
    'premium:'||v_pkg.code,
    null,
    '{}'::jsonb
  );

  insert into public.admin_revenue_ledger(
    source,reference_id,amount_bdt,settled_amount_bdt,withdrawable_amount_bdt,metadata
  ) values(
    'premium_sale',v_ref,v_order.amount_bdt,v_order.amount_bdt,v_order.amount_bdt,
    jsonb_build_object('telegram_id',v_order.telegram_id,'package',v_pkg.code)
  ) on conflict(source,reference_id) do nothing;

  insert into public.admin_logs(admin_id,action,target_id,metadata)
  values(p_admin_id,'premium_verified',p_order_id::text,
    jsonb_build_object('telegram_id',v_order.telegram_id,'package',v_pkg.code));

  return jsonb_build_object('ok',true,'status','verified','active_account',true);
end;
$$;

create or replace function public.reject_premium_order(
  p_admin_id bigint,
  p_order_id uuid,
  p_reason text default null
)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
begin
  if not public.is_admin(p_admin_id) then raise exception 'admin only'; end if;

  update public.premium_orders
  set status='rejected',
      rejection_reason=p_reason,
      updated_at=now()
  where id=p_order_id and status='pending';

  insert into public.admin_logs(admin_id,action,target_id,metadata)
  values(p_admin_id,'premium_rejected',p_order_id::text,
    jsonb_build_object('reason',p_reason));

  return jsonb_build_object('ok',true,'status','rejected');
end;
$$;

create or replace function public.create_withdrawal(
  p_telegram_id bigint,
  p_amount bigint,
  p_method text,
  p_account text
)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare v_user public.users%rowtype; v_id uuid;
begin
  select * into v_user from public.users
  where telegram_id=p_telegram_id for update;

  if not found or not v_user.is_active_account or v_user.status<>'active'
    then raise exception 'account not active'; end if;
  if p_amount < 500 then raise exception 'minimum withdrawal is 500'; end if;
  if p_method not in ('bkash','nagad') then raise exception 'invalid method'; end if;
  if v_user.balance < p_amount then raise exception 'insufficient balance'; end if;

  update public.users set balance=balance-p_amount, updated_at=now()
  where telegram_id=p_telegram_id;

  insert into public.withdrawals(telegram_id,amount,method,account)
  values(p_telegram_id,p_amount,p_method,p_account)
  returning id into v_id;

  insert into public.wallet_transactions(telegram_id,tx_type,amount,reference_id)
  values(p_telegram_id,'withdrawal',-p_amount,v_id::text);

  return jsonb_build_object('ok',true,'withdrawal_id',v_id,'status','pending');
end;
$$;

-- Lock mutation RPCs to service_role in production.
revoke all on function public._grant_credit_internal(bigint,bigint,text,text,text,timestamptz,jsonb) from public, anon, authenticated;
revoke all on function public.verify_premium_order(bigint,uuid) from public, anon, authenticated;
revoke all on function public.reject_premium_order(bigint,uuid,text) from public, anon, authenticated;
revoke all on function public.match_payment_evidence(bigint,uuid,text,text) from public, anon, authenticated;
revoke all on function public.create_withdrawal(bigint,bigint,text,text) from public, anon, authenticated;
