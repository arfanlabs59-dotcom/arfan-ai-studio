import test from "node:test";
import assert from "node:assert/strict";

function normalizeTrxId(v) {
  return String(v || "").trim().toUpperCase().replace(/\s+/g, "");
}

test("TRX normalization", () => {
  assert.equal(normalizeTrxId(" ab 12-c "), "AB12-C");
});

test("minimum withdrawal rule", () => {
  assert.equal(500 >= 500, true);
  assert.equal(499 >= 500, false);
});
