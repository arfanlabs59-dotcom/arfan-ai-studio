// Conceptual handler contract.
// Wire into the existing Telegraf bot rather than creating a second bot instance.

async function saveProfilePhoto(telegramId, fileId, fileUrl = null) {
  const { error } = await supabase
    .from("users")
    .update({
      profile_photo_file_id: fileId,
      profile_photo_url: fileUrl,
      profile_photo_updated_at: new Date().toISOString(),
    })
    .eq("telegram_id", telegramId);

  if (error) throw error;
}
